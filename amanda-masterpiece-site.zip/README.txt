Instruções Rápidas
- Extraia os arquivos e coloque em um repositório GitHub (raiz).
- Para utilizar as imagens de casal, arraste/solte sobre a área 'Casais de Anime' ou use o seletor de arquivos.
- A música é gerada via WebAudio; use o botão 'Música' para ligar/desligar e o controle de volume.
- Se quiser que eu faça upload direto ou substituir frases, me envie as imagens e eu atualizo os arquivos.
